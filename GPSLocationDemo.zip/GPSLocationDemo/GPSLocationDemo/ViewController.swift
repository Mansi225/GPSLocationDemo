//
//  ViewController.swift
//  GPSLocationDemo
//
//  Created by MAC2 on 24/11/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController,CLLocationManagerDelegate
{
    let locManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    map.showsUserLocation = true
    if CLLocationManager.locationServicesEnabled()
    {
        switch(CLLocationManager.authorizationStatus())
        {
        case.notDetermined, .restricted, .denied:
            print("You don't have access!!")
        case.authorizedAlways , .authorizedWhenInUse :
            print("Access granted!!")
        }
    }
    else
    {
            print("Location service are not enable..")
    }
    locManager.delegate = self
    locManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
    locManager.requestWhenInUseAuthorization()
    locManager.requestAlwaysAuthorization()
    locManager.startUpdatingLocation()
    }

    @IBOutlet weak var map: MKMapView!
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        let cls = locations[0]
        let lat = cls.coordinate.latitude
        let log = cls.coordinate.longitude
        print("Latitude..\(lat)")
        print("Logitude..\(log)")
        CLGeocoder().reverseGeocodeLocation(cls) { (plackmarks, error) in
            if error != nil
            {
                print("Failed with error : \(String(describing: error?.localizedDescription))")
            }
            if (plackmarks?.count)! > 0
            {
                let pm = plackmarks?[0]
                print("Locality : \(String(describing: pm?.locality))")
                print("Country : \(String(describing: pm?.country))")
                print("Postalcode : \(String(describing: pm?.postalCode))")
                print("Name : \(String(describing: pm?.name))")
                print("SubLocality : \(String(describing: pm?.subLocality))")
                
            }
            else {
                print("Problem with the data received from geocoder")
            }
        }
        locManager.stopUpdatingLocation()
        let center = CLLocationCoordinate2D(latitude: cls.coordinate.latitude, longitude: cls.coordinate.longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        self.map.setRegion(region, animated: true)
        let NYLocation = CLLocationCoordinate2D(latitude: lat, longitude: log)
        let droppin = MKPointAnnotation()
        droppin.coordinate = NYLocation
        droppin.title = "New York City"
        map.addAnnotation(droppin)
        
        
    }
    
    
}

